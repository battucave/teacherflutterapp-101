package com.wrteam.eschool.teacher

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
