import 'package:eschool_teacher/app/app.dart';

//v-1.0.1
void main() {
  initializeApp();
}
