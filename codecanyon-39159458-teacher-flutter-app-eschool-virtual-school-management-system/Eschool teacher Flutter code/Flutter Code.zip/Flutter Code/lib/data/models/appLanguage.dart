class AppLanguage {
  final String languageName;
  final String languageCode;

  const AppLanguage({required this.languageCode, required this.languageName});
}
