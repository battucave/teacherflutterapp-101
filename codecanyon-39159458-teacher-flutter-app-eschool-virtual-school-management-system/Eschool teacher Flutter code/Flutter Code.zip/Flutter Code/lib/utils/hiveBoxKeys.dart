//Authbox keys
const String authBoxKey = "authBox";
const String jwtTokenKey = "jwtToken";
const String isLogInKey = "isLogIn";
const String teacherDetailsKey = "teacherDetails";
//Settings box key

const String settingsBoxKey = "settings";
const String currentLanguageCodeKey = "currentLanguageCode";
